const isValidUser = (req, res, next) => {
    if (req.session.isValid) {
        next();
    } else {
        res.redirect("/");
    }
};


const driverAuthenticated = (req, res, next) => {
    if (req.session.userType === 'driver') {
        return next();
    }
    res.status(403).send('Access is denied'); 
}
const adminAuthenticated = (req, res, next) => {
    if (req.session.userType === 'admin') {
        return next();
    }
    res.status(403).send('Access denied'); 
}

const passCommonData = (req, res, next) => {
    res.locals.isValid = req.session.isValid;
    res.locals.userType = req.session.userType;
    next();
}

module.exports = {isValidUser, driverAuthenticated, passCommonData,adminAuthenticated};

const bcrypt = require('bcrypt');
const driver_model = require('../models/driverTestCentre.js');
const appointment_model = require('../models/appointment.js');
const e = require('express');


class Controller {


    static login_get = (req, res) => {
        res.render("login.ejs", { errMessages: null });
        console.log('here');
    };

    static login_post = async (req, res) => {
        try {
            const form_data = req.body;
            let exisintg_user = await driver_model.findOne({
                userName: form_data.username,
            });
            if (!exisintg_user) {
                return res.render('login.ejs', { errMessages: "User not found, Please signup first." });
            }
            const user_matched = await bcrypt.compare(
                form_data.password,
                exisintg_user.password
            );
            console.log(user_matched)
            console.log(form_data)
            if (user_matched) {

                req.session.isValid = true;
                req.session.user = exisintg_user.firstName;
                req.session.userType = exisintg_user.userType;
                req.session.userId = exisintg_user._id;

                return res.redirect("/dashboard");
            } else {
                // res.send("Invalid username or password");
                return res.render('login.ejs', { errMessages: "Incorrect password" });
            }
            res.send(user_matched);
        } catch (err) {
            console.log(err);
            return res.send(err);
        }
    }

    static signup_get = (req, res) => {
        res.render("signup.ejs", { errMessages: null });
    };

    static signup_post = async (req, res) => {
        try {
            const form_data = req.body;
            // compare password and confirm password
            if (form_data.password !== form_data.confirmPassword) {
                res.render("signup.ejs", { errMessages: "Password and Confirm Password do not match" });
            }

            let user = await driver_model.findOne({ userName: form_data.username });

            if (!user) {
                const hashedPwd = await bcrypt.hash(form_data.password, 10);
                user = new driver_model({
                    userName: form_data.username,
                    password: hashedPwd,
                    userType: form_data.userType,
                });
                const user_saved = user.save();
                res.redirect('/login');
            }
            else {
                res.render("signup.ejs", { errMessages: "Username already exits." });
            }
        } catch { }
    };

    static logout_post = (req, res) => {
        req.session.destroy((err) => {
            if (err) {
                throw err;
            }
            res.redirect('/');
        });
    };


    static dashboard_get = (req, res) => {
        res.render("dashboard.ejs");
    };

    static g2page_get = async (req, res) => {

        // Get User
        const userData = await driver_model.findOne({ _id: req.session.userId });

        if (userData && userData.licenseNumber !== 'default') {
            userData['dobFormated'] = userData.dob.toISOString().split('T')[0];
            userData.make = userData.car_details.make;
            userData.model = userData.car_details.model;
            userData.year = userData.car_details.year;
            userData.plateNumber = userData.car_details.plateNumber;
            userData.isFilled = true;

            const slot = await appointment_model.findOne({ _id: userData.appointmentId });
            slot.slotDate = slot.date.toISOString().split('T')[0];
            

            return res.render("g2page.ejs", { errMessages: {}, userData: userData, slot: slot });
        }
        return res.render("bookings.ejs", { date: null, slots: null , errorMessage: null});
    }

    static g2page_post = async (req, res) => {
        try {
            const formData = Controller.trimFormData(req.body);

            const slot = await appointment_model.findOne({ _id: formData.slotId });
            slot.slotDate = slot.date.toISOString().split('T')[0];

            // Validate form data
            const errMessages = this.formValidation(formData);
            if (Object.keys(errMessages).length > 0) {
                return res.render('g2page', { errMessages: errMessages, userData: formData, slot: slot });
            }

            // Encrypt license number
            const licenseNumber = formData['licenseNumber'];
            const hashedlicenseNumber = bcrypt.hashSync(licenseNumber, 10);

            // Save driver's information to MongoDB
            const dataToUpadate = {
                firstName: formData['firstName'],
                lastName: formData['lastName'],
                licenseNumber: hashedlicenseNumber,
                age: formData['age'],
                dob: formData['dob'],
                car_details: {
                    make: formData['make'],
                    model: formData['model'],
                    year: formData['year'],
                    plateNumber: formData['plateNumber']
                },
                appointmentId: formData.slotId
            };
            const driver = await driver_model.findOneAndUpdate({ _id: req.session.userId }, dataToUpadate);
            const savedDriver = await driver.save();

            // make slot unavailable
            slot.isTimeSlotAvailable = false;
            const updatedSlot = await slot.save();

            res.redirect('/g2page');

        } catch (err) {
            console.log("Driver's information not saved to MongoDB due to error below:\n", err);
            res.send('An error occurred while saving driver information.');
        }
    }


    static g2page_fetch_slots = async (req, res) => {
        try {
            const formData = req.body;
            let slots = await appointment_model.find({ date: formData.date });

            if (slots.length === 0) {
                slots = undefined;
            }
            res.render("bookings.ejs", { date: formData.date, slots: slots, errorMessage: null});
        } catch (err) {
            console.log(err);
        }
    }

    // Set slot
    static g2page_set_slot = async (req, res) => {
        try {
            const formData = req.body;
            console.log("formData", formData);

            if (typeof formData.time !== 'string'){
                if (formData.time.length === 0) {
                    res.render("bookings.ejs", { date: formData.date, slots: [] , errorMessage: "Please select slot for booking" });
                }
        };
            const slot = await appointment_model.findOne({ date: formData.date, time: formData.time });

            // If slot is not available, render bookings.ejs with no slot
            if (!slot) {
                res.render("bookings.ejs", { date: formData.date, slots: [] , errorMessage: "Slot not available for booking"});
            }

            slot.slotDate = slot.date.toISOString().split('T')[0];
            return res.render("g2page.ejs", { errMessages: {}, userData: {}, slot: slot });
        } catch (err) {
            console.log(err);
        }
    }


    static gpage_get = async (req, res) => {
        // Get User
        const userData = await driver_model.findOne({ _id: req.session.userId });

        if (userData && userData.licenseNumber !== 'default') {
            userData['dobFormated'] = userData.dob.toISOString().split('T')[0];
            return res.render("gpage.ejs", { errMessages: {}, userData: userData });
        } else {
            return res.redirect('/g2page');
        }
    }

    static gpage_post = async (req, res) => {
        console.log("gpage_post");
        try {
            const formData = req.body;

            // Extract car details from form data
            const carDetails = {
                make: formData.make,
                model: formData.model,
                year: formData.year,
                plateNumber: formData.plateNumber
            };

            // Find driver by license number
            const driver = await driver_model.findOne({ _id: req.session.userId });
            console.log("driver", driver);

            // Construct user data object with updated car details
            const userData = {
                firstName: driver.firstName,
                lastName: driver.lastName,
                age: driver.age,
                dob: driver.dob,
                car_details: carDetails,
                dobFormated: driver.dob.toISOString().split('T')[0]
            };

            // Validate form data
            const errMessages = this.formValidation(formData);
            const errMessagesKeys = Object.keys(errMessages);

            // If validation errors exist for car details, render gpage.ejs with error messages and user data
            if (errMessagesKeys.includes('make') || errMessagesKeys.includes('model') ||
                errMessagesKeys.includes('year') || errMessagesKeys.includes('plateNumber')) {
                return res.render('gpage.ejs', { errMessages: errMessages, userData: userData });
            }

            // Update driver's car details in the database
            const updatedDriver = await driver_model.findOneAndUpdate({ _id: req.session.userId }, { car_details: carDetails });
            // Save the updated driver
            updatedDriver.save();

            // Render dashboard.ejs upon successful update
            res.render("dashboard.ejs");
        } catch (err) {
            // If an error occurs, send an error response
            res.status(401).send({ message: err.message });
        }
    };

    static appointment_get = (req, res) => {
        console.log("appointment_get");
        res.render("appointment.ejs", { slots: [], date: null , errorMessage: null});
    }

    // Fetch available slots for the selected date
    static appointment_fetch_slots = async (req, res) => {
        try {
            const formData = req.body;

            const date = formData.date;

            // List of available slots
            const list_of_slots = [ '10:00', '10:30', '11:00', '11:30', '12:00', '12:30', '13:00', '13:30', '14:00']

            // Fetch available slots for the selected date
            let slots = await appointment_model.find({ date: date });

            const length = Object.keys(slots).length;

            const slots_to_display = [];
            if (length === 0) {
                // If no slots are available for the selected date, display all slots as available
                for (let i = 0; i < list_of_slots.length; i++) {
                    const slotTime = list_of_slots[i];
                    slots_to_display.push({ time: slotTime, isAlreadyCreated: true });
                }
            } else {
                // If slots are available for the selected date, display only the available slots
                let isAlreadyCreated = true;
                let timeArray = slots.map(slot => slot.time);
                for (let i = 0; i < list_of_slots.length; i++) {
                    const slotTime = list_of_slots[i];
                    if (timeArray.includes(slotTime)) {
                        isAlreadyCreated = false;
                    } else {
                        isAlreadyCreated = true;
                    }
                    // Add slot to slots_to_display array
                    slots_to_display.push({ time: slotTime, isAlreadyCreated: isAlreadyCreated });
                }
            }
            res.render("appointment.ejs", { slots: slots_to_display, date: date, errorMessage: null});

        } catch (err) {
            console.log(err);
        }

    }

    static appointment_create_slots = async (req, res) => {
        try {
            const formData = req.body;
    
            console.log("formData", formData);
    
            if (!formData.date || !formData.selectedSlot) {
                res.render("appointment.ejs", { slots: [], date: null, errorMessage: "Please select slot for booking" });
                return; // Exit the function early if required data is missing
            }
    
            // Create a new slot
            const slot = new appointment_model({
                date: formData.date,
                time: formData.selectedSlot, // Use the selected slot value
                isTimeSlotAvailable: true
            });
            const savedSlot = await slot.save();
    
            res.render("appointment.ejs", { slots: [], date: formData.date, errorMessage: 'Slot created successfully' });
        } catch (err) {
            console.log(err);
        }
    }
    

}


Controller.trimFormData = (formData) => {
    const trimmedData = {};
    for (const key in formData) {
        trimmedData[key] = formData[key].trim();
    }
    return trimmedData;
};


Controller.formValidation = (formData) => {
    // Object to store error messages
    const errMessages = {};

    // Validation for First Name
    if (formData['firstName'] === '') {
        errMessages['firstName'] = "First Name is required";
    } else if (typeof formData['firstName'] !== 'string' || parseInt(formData['firstName'])) {
        errMessages['firstName'] = "First Name must be a string";
    }

    // Validation for Last Name
    if (formData['lastName'] === '') {
        errMessages['lastName'] = "Last Name is required";
    } else if (typeof formData['lastName'] !== 'string' || parseInt(formData['lastName'])) {
        errMessages['lastName'] = "Last Name must be a string";
    }

    // Validation for License Number
    if (Object.keys(formData).includes('licenseNumber')) {
        if (formData['licenseNumber'] === '') {
            errMessages['licenseNumber'] = "License Number is required";
        } else if (formData['licenseNumber'].length !== 8) {
            errMessages['licenseNumber'] = "License Number must be 8 characters long";
        }
    }

    // Validation for Age
    if (formData['age'] === '') {
        errMessages['age'] = "Age is required";
    } else if (formData['age'] <= 16 || formData['age'] >= 60) {
        errMessages['age'] = "Age must be between 16 and 60";
    }

    // Validation for Date of Birth
    if (formData['dob'] === '') {
        errMessages['dob'] = "Date of Birth is required";
    }

    // Validation for Make
    if (formData['make'] === '') {
        errMessages['make'] = "Make is required";
    } else if (parseInt(formData['make'])) {
        errMessages['make'] = "Make must be a string";
    }

    // Validation for Model
    if (formData['model'] === '') {
        errMessages['model'] = "Model is required";
    } else if (parseInt(formData['model'])) {
        errMessages['model'] = "Model must be a string";
    }

    // Validation for Year
    if (formData['year'] === '') {
        errMessages['year'] = "Year is required";
    } else if (parseInt(formData['year']) < 1990 || parseInt(formData['year']) >= new Date().getFullYear() + 1) {
        errMessages['year'] = `Year must be between 1990 and ${new Date().getFullYear()}`;
    }

    // Validation for Plate Number
    if (formData['plateNumber'] === '') {
        errMessages['plateNumber'] = "Plate Number is required";
    } else if (formData['plateNumber'].length !== 6) {
        errMessages['plateNumber'] = "Plate Number must be 6 characters long";
    }

    // Return error messages object
    return errMessages;
};

module.exports = Controller;
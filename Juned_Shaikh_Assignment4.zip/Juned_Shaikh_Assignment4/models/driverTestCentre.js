const  mongoose = require('mongoose')

const { Types } = mongoose;

const uri = "mongodb+srv://junedshaikh6910:C4FHc4vAnozCdx4k@cluster0.a5jxr8c.mongodb.net/LeonsEmployees?retryWrites=true&w=majority"
mongoose.connect(uri).then(() => console.log("****Connected to MongoDb successfully****"))
 .catch((err) => console.log(`Connection Failed due to error below\n${err}`))

 const driving_center = mongoose.Schema({

    firstName: { type: String, required: true, default: 'default'},
    lastName: { type: String, required: true, default: 'default'},
    licenseNumber: { type: String, required: true, default: 'default'},
    age: { type: Number, required: true, default: 0},
    dob: { type: Date, required: true, default: Date.now()},
    userName: { type: String, required: true},
    password: { type: String, required: true},
    userType: {type : String, required: true, enum: ['driver', 'examiner','admin']},
    car_details:{
        make: { type: String, required: true, default: 'default'},  
        model: { type: String, required: true, default: 'default'}, 
        year: { type: String, required: true, default: 'default'},    
        plateNumber: { type: String, required: true, default: 'default'}
    },
    appointmentId: {
        type: Types.ObjectId, ref: 'appointment'
      },
});

 const driver_model = mongoose.model("driver",driving_center)

 module.exports = driver_model;
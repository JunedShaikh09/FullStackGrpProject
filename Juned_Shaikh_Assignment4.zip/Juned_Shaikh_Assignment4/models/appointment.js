const  mongoose = require('mongoose')


 const appointment = mongoose.Schema({

    date : { type: Date, required: true},
    time : { type: String, required: true},
    isTimeSlotAvailable : { type: Boolean, required: true, default: true},

});

 const appointment_model = mongoose.model("appointment",appointment)

 module.exports = appointment_model;
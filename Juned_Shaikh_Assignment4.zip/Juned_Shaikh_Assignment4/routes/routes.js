const express = require('express');
const router = express.Router();
const {isValidUser, driverAuthenticated, passCommonData, adminAuthenticated} = require('../middlewares/validate.js');

const Controller = require('../controller/controller.js');


router.get('/',passCommonData,Controller.dashboard_get);
router.get('/dashboard',passCommonData, Controller.dashboard_get);


router.get('/g2page',isValidUser, driverAuthenticated,passCommonData, Controller.g2page_get);
router.post('/g2page',isValidUser, driverAuthenticated,passCommonData, Controller.g2page_post);

router.get('/gpage',isValidUser, driverAuthenticated,passCommonData, Controller.gpage_get);
router.post('/gpage',isValidUser, driverAuthenticated,passCommonData, Controller.gpage_post);

router.get('/appointment',isValidUser, adminAuthenticated,passCommonData, Controller.appointment_get);
// router.post('/appointment',isValidUser, adminAuthenticated,passCommonData, Controller.appointment_post);

router.post('/appointments/fetch-slots',isValidUser, adminAuthenticated,passCommonData, Controller.appointment_fetch_slots);
router.post('/appointments/create-slots',isValidUser, adminAuthenticated,passCommonData, Controller.appointment_create_slots);

router.post('/g2page/fetch-slots',isValidUser, driverAuthenticated,passCommonData, Controller.g2page_fetch_slots);
router.post('/g2page/set-slot',isValidUser, driverAuthenticated,passCommonData, Controller.g2page_set_slot);

router.get("/signup", Controller.signup_get);
router.post("/signup", Controller.signup_post);
router.get("/login", Controller.login_get);
router.post("/login", Controller.login_post);
router.get("/logout", Controller.logout_post);

module.exports = router;

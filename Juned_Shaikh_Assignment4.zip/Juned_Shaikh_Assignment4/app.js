console.log("Welcome!!!!!!!!!!")


const express = require('express')
const app = express()
const router = require('./routes/routes.js');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const crypto = require('crypto');

const secretKey = crypto.randomBytes(32).toString('hex');


const uri = "mongodb+srv://junedshaikh6910:C4FHc4vAnozCdx4k@cluster0.a5jxr8c.mongodb.net/LeonsEmployees?retryWrites=true&w=majority"

// Create a session store using the MongoDB connection
const session_store = MongoStore.create({
    mongoUrl : uri ,
    dbName : 'LeonsEmployees',
    collectionName : 'userSessions',
})

// Set the view engine to use EJS files
app.set('view engine', 'ejs');

// Use the public folder for static files
app.use(express.static('public'))

// Parse url encoded bodies
app.use(express.urlencoded({ extended: true }));

// Parse json bodies
app.use(session({
    secret : secretKey,
    saveUninitialized : false ,
    resave : false,
    store : session_store
}))


// Start the server on port 9090
app.listen(9040, () => {
    console.log("Server is listening at port 9040!!!!")
})

app.use("/", router);